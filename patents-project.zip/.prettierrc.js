module.exports = {
  arrowParens: 'always',
  singleQuote: false,
  jsxSingleQuote: false,
  tabWidth: 2,
  semi: true,
};
